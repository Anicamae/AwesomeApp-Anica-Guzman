//
//  ViewController.swift
//  AwesomeApp-Anica-Guzman
//
//  Created by Anica Guzman on 9/1/20.
//  Copyright © 2020 SFSU. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

